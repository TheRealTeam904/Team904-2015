package org.usfirst.frc.team904.robot;
/**
 * The RobotMap is a mapping from the ports sensors and actuators are wired into
 * to a variable name. This provides flexibility changing wiring, makes checking
 * the wiring easier and significantly reduces the number of magic numbers
 * floating around.
 */
public class RobotMap {
	   public static int leftFrontMotor = 1;
	    public static int rightFrontMotor = 2;
	    public static int leftBackMotor = 3;
	    public static int rightBackMotor = 4;
	    
	    public static int forkliftChannel = 0;

	    public static int joystickChannel = 0;
	    public static int joystickOperationChannel = 0;

	    //FYI- this is the arm relay channel
	    public static int spikeChannel = 1;
	    
	    public static int[] forkliftEncoderChannel = {0 , 1};
	    public static int[] encoderFrontLeft = {2, 3};
	    public static int[] encoderFrontRight = {4, 5};
	    public static int[] encoderBackLeft = {6, 7};
	    public static int[] encoderBackRight = {8, 9};
	    
	    public static int baseLevel = 0;
	    public static int levelGoTo = 0;
}
