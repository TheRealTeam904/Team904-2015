package org.usfirst.frc.team904.robot.subsystems;

import org.usfirst.frc.team904.robot.Robot;
import org.usfirst.frc.team904.robot.RobotMap;

import edu.wpi.first.wpilibj.SpeedController;
import edu.wpi.first.wpilibj.Talon;
import edu.wpi.first.wpilibj.command.PIDSubsystem;
import edu.wpi.first.wpilibj.livewindow.LiveWindow;

/**
 *
 */
public class pidDrive extends PIDSubsystem {
	
	private static final double Kp = 0.0;
	private static final double Ki = 0.0;
	private static final double Kd = 0.0;

	SpeedController leftFront = new Talon(RobotMap.leftFrontMotor);
	SpeedController rightFront = new Talon(RobotMap.rightFrontMotor);
	SpeedController leftBack = new Talon(RobotMap.leftBackMotor);
	SpeedController rightBack = new Talon(RobotMap.rightBackMotor);

    // Initialize your subsystem here
    public pidDrive() {
    	super("ForkliftChangeHeight", Kp, Ki, Kd);
    	LiveWindow.addSensor("Drive Encoder", "PID Subsystem Controller", getPIDController());
    	setSetpoint(RobotMap.baseLevel);
    	enable();    
    }
    
    public void initDefaultCommand() {}
    
    protected double returnPIDInput() {
    	return Robot.encoderFrontLeft.getDistance();
    }
    
    protected void usePIDOutput(double output) {
    	leftFront.set(output);
    	leftFront.set(output);
    	leftFront.set(output);
    	leftFront.set(output);
    }
}
