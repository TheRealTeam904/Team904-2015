package org.usfirst.frc.team904.robot.subsystems;

import org.usfirst.frc.team904.robot.OI;
import org.usfirst.frc.team904.robot.RobotMap;
import org.usfirst.frc.team904.robot.commands.forkliftDoNothing;

//import edu.wpi.first.wpilibj.Encoder;
//import edu.wpi.first.wpilibj.Relay;
import edu.wpi.first.wpilibj.Talon;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.command.Subsystem;

/**
 *
 */
public class Forklift extends Subsystem {
    
	private static Talon m_Talon;								// Talon which drives the forklift
	private static final double forkliftSpeed = .25;		// Forklift Speed Magnitude. Change this to make the forklift go slower. NO NEGATIVES
	//private static final double baseHeight = 0; 			// Forklift base height above ground (cm)
    public void initDefaultCommand() {
        // Set the default command for a subsystem here.
        setDefaultCommand(new forkliftDoNothing());
    }
    
    public Forklift(int relayChannel) {
		m_Talon = new Talon(RobotMap.forkliftChannel);
		System.out.println("Forklift Initialization complete");
		
	}
	
    public static void goUp() {
		System.out.println("\nForklift going up!");
    	m_Talon.set(forkliftSpeed);    
    	//TODO: Have some way to stop this when it hits the top
    }
    
    public static void goDown() {
		System.out.println("\nForklift going down!");
		m_Talon.set(-forkliftSpeed); // TODO: Have some way of stopping this when it hits bottom
	}
    public static void joystickControl() {

    	m_Talon.set(OI.stickOperation.getY());
        
        Timer.delay(0.005);	// wait 5ms to avoid hogging CPU cycles
}

    public static void stop() {
		m_Talon.set(0);
		Timer.delay(0.005);
	}
}

