package org.usfirst.frc.team904.robot;

import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.buttons.Button;
import edu.wpi.first.wpilibj.buttons.JoystickButton;

import org.usfirst.frc.team904.robot.commands.ArmOpen;
import org.usfirst.frc.team904.robot.commands.ArmRelease;
import org.usfirst.frc.team904.robot.commands.ForkliftDown;
import org.usfirst.frc.team904.robot.commands.ForkliftUp;
import org.usfirst.frc.team904.robot.commands.goUpOrDown;

/**
 * This class is the glue that binds the controls on the physical operator
 * interface to the commands and command groups that allow control of the robot.
 */
public class OI {
    //// CREATING BUTTONS
	public static Joystick stick = new Joystick(RobotMap.joystickChannel),
						   stickOperation = new Joystick(RobotMap.joystickOperationChannel);
	
    public static Button forkliftUpButton = new JoystickButton(stickOperation, 1),
    					 forkliftDownButton = new JoystickButton(stickOperation, 2),
    					 armsGripButton = new JoystickButton(stickOperation, 3),
    					 armsReleaseButton = new JoystickButton(stickOperation, 4);
    
	public static Button firstPosition = new JoystickButton(stickOperation, 7),
				   		 secondPosition = new JoystickButton(stickOperation, 8),
				   		 thirdPosition = new JoystickButton(stickOperation, 9),
				   		 fourthPosition = new JoystickButton(stickOperation, 10),
				   		 fifthPosition = new JoystickButton(stickOperation, 11),
				   		 sixthPosition = new JoystickButton(stickOperation, 12);


	public OI(){
    //// TRIGGERING COMMANDS WITH BUTTONS
	forkliftUpButton.whileHeld(new ForkliftUp());
    forkliftDownButton.whileHeld(new ForkliftDown()); 
    armsGripButton.whileHeld(new ArmOpen());
    armsReleaseButton.whileHeld(new ArmRelease());
    firstPosition.whenPressed(new goUpOrDown(1));
    secondPosition.whenPressed(new goUpOrDown(2));
    thirdPosition.whenPressed(new goUpOrDown(3));
    fourthPosition.whenPressed(new goUpOrDown(4));    
    fifthPosition.whenPressed(new goUpOrDown(5));
    sixthPosition.whenPressed(new goUpOrDown(6));


    }
}

